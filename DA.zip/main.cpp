#include "mpi.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
#define THREADS 4
// cu tot cu /n
pthread_barrier_t barrier;
pthread_barrier_t barrier1;
string input;

std::vector<std::string> split_string(const std::string& str,
                                      const std::string& delimiter) {
  std::vector<std::string> strings;

  std::string::size_type pos = 0;
  std::string::size_type prev = 0;
  while ((pos = str.find(delimiter, prev)) != std::string::npos) {
    strings.push_back(str.substr(prev, pos - prev));
    prev = pos + 1;
  }
  strings.push_back(str.substr(prev));

  return strings;
}

bool isVowel(char ch) 
{ 
  if(toupper(ch) == 'A' || toupper(ch) == 'E' || toupper(ch) == 'I' || toupper(ch) == 'O' || toupper(ch) == 'U'){
      return true;
  } else {
      return false;
  }
} 
string duplicateVowels(string str) 
{ 
    int t = str.length(); 
  
    // Another string to store 
    // the resultant string 
    string res = ""; 
  
    // Loop to check for each character
    int x = 0;
    while(x < str.length()) { 
        if (isVowel(str[x]) == false && isalpha(str[x])) { 
            res += str[x];
            res += tolower(str[x]); 
        }
        else{ 
        res +=str[x];
        } 
        x++;
    } 
  
    return res; 
} 

struct genreProcessing {
  int idthread;
  int genreid;
  int numthreads;
  int size;
};
vector<string> comedySent, science, horror, fantasy;
queue<string> paragraphs[4];
unordered_map<int, string> constantMap = {
    {0, "comedy"}, {1, "horror"}, {2, "science-fiction"}, {3, "fantasy"}};
unordered_map<string, int> revconstantMap = {
    {"comedy",0}, {"horror",1}, {"science-fiction",2}, {"fantasy",3}};

void* textprocessing(void* arg) {
  genreProcessing* args = (genreProcessing*)arg;
  int start = args->idthread * (double)  args->size / args->numthreads;
  int end = min((args->idthread + 1) *  args->size / args->numthreads, args->size);
  switch(args->genreid){
    case 3:{
      int i = start;
        while(i < end) {
          science[i][0] = toupper(science[i][0]);
          int k = 1;
        while(k < science[i].size()) {
        if (science[i][k - 1] == ' ') {
          science[i][k] = toupper(science[i][k]);
        }
        k++;
      }
      i++;
    }
    pthread_barrier_wait(&barrier1);
    if (args->idthread == 0) {
      string x;
      for (int i = 0; i < science.size(); i++) {
        x += science[i];
        x += "\n";
      }
      MPI_Send(x.c_str(), x.size(), MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }
    break;
    }
    case 0:{
      int i = start;
      while(i < end) {
        int k = 0;
      while(k < comedySent[i].size()) {
        if (comedySent[i][k] != ' ') {
          int index = 1;
          while (comedySent[i][k] != ' ' && k < comedySent[i].size()) {
            if (index % 2 == 0) {
              comedySent[i][k] = toupper(comedySent[i][k]);
            }
            index++;
            k++;
          }
        }
        k++;
      }
      i++;
    }
    pthread_barrier_wait(&barrier1);
    if (args->idthread == 0) {
      string x;
      for (int i = 0; i < comedySent.size(); i++) {
        x += comedySent[i];
        x += "\n";
      }
      MPI_Send(x.c_str(), x.size(), MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }
    break;
    }
    case 2:{
      int i = start;
       while (i < end) {
      vector<string> auxiliary =  split_string(fantasy[i]," ");
        int h = 0;
        while(h < auxiliary.size()){
          if( (h + 1) % 7 == 0){
            reverse(auxiliary[h].begin(),auxiliary[h].end());
          }
          h++;
        }
        fantasy[i] = "";
        for(auto it: auxiliary){
          fantasy[i] += it;
          fantasy[i] +=" ";
        }
      i++;
    }
    pthread_barrier_wait(&barrier1);
    if (args->idthread == 0) {
      string x;
      for (int i = 0; i < fantasy.size(); i++) {
        x += fantasy[i];
        x += "\n";
      }
      MPI_Send(x.c_str(), x.size(), MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }
    break;
    }
    case 1:{
      int i = start;
         while(i < end) {
     vector<string> auxiliary =  split_string(horror[i]," ");
     int h = 0;
       while(h < auxiliary.size()){
              auxiliary[h] = duplicateVowels(auxiliary[h]);        
              h++; 
        }
        horror[i] = "";
        for(auto it: auxiliary){
          horror[i] += it;
          horror[i] +=" ";
        }
        i++;
    }
    pthread_barrier_wait(&barrier1);
    if (args->idthread == 0) {
      string x;
      for (int i = 0; i < horror.size(); i++) {
        x += horror[i];
        x += "\n";
      }
      MPI_Send(x.c_str(), x.size(), MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }
    break;
    }
    default:{
      break;
    }
  }
  free(args);
  pthread_exit(NULL);
}

void* receiver(void* arg) {
  bool wait = true;
  int id = *(int*) arg;
 
  vector<string> aux;
  while (wait) {
    MPI_Status status;
    MPI_Probe(0, 0, MPI_COMM_WORLD, &status);
    int count = 0;
    MPI_Get_count(&status, MPI_CHAR, &count);
    char buf[count];
    MPI_Recv(&buf, count, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status);
    string s = buf;
    s.resize(count);
    if (s == "stop") {
      wait = false;
    } else {
      int lines = 0;
      aux.push_back(s);
      for (auto it : s) {
        if (it == '\n') {
          lines++;
        }
      }
      int P;
       if (lines / 20 + 1 > sysconf(_SC_NPROCESSORS_CONF)) {
         P = sysconf(_SC_NPROCESSORS_CONF);
         } else{
           P = lines / 20 + 1;
         }
      pthread_t threads[P];
      int r;
      int mysize;
      if (id == 0) {
        comedySent = split_string(s, "\n");
        mysize = comedySent.size();
      } else if (id == 3) {
        science = split_string(s, "\n");
        mysize = science.size();
      }
       else if (id == 2) {
        fantasy = split_string(s, "\n");
        mysize = fantasy.size();
      }
       else if (id == 1) {
        horror = split_string(s, "\n");
        mysize = horror.size();
      }
      pthread_barrier_init(&barrier1, NULL, P);
      for (int i = 0; i < P; ++i) {
        genreProcessing* arg = (genreProcessing*)malloc(sizeof(*arg));
        arg->size = mysize;
        arg->idthread = i;
        arg->genreid = id;
        arg->numthreads = P;

        r = pthread_create(&threads[i], NULL, textprocessing, (void*)arg);
        if (r) {
          exit(EXIT_FAILURE);
        }
      }
      void* stat;
      for (int i = 0; i < P; ++i) {
        r = pthread_join(threads[i], &stat);
        if (r) {
          exit(EXIT_FAILURE);
        }
      }
    }
  }
  pthread_exit(NULL);
}

void* readFunction(void* arg) {
  int id = *(int*) arg;
  ifstream f(input);
  string s;
  vector<string> aux, correctOrder;
  while (getline(f, s)) {
    if(id == 0 && "horror" == s || "science-fiction" == s  || "fantasy" == s || "comedy" == s ){
      correctOrder.push_back(s);
    }
    if (s == constantMap[id]) {
      string iterate, auxx;
      while (getline(f, iterate)) {
        if (!iterate.empty()) {
          iterate.append("\n");
          auxx.append(iterate);
        } else {
          break;
        }
      }
      aux.push_back(auxx);
    }
  }
  for (auto it : aux) {
    MPI_Status status;
    int count = 0;
    MPI_Send(it.c_str(), it.size(), MPI_CHAR, id + 1, 0, MPI_COMM_WORLD);
    MPI_Probe(id + 1, 0, MPI_COMM_WORLD, &status);

    MPI_Get_count(&status, MPI_CHAR, &count);
    char buf[count];
    MPI_Recv(&buf, count, MPI_CHAR, id + 1, 0, MPI_COMM_WORLD, &status);
    string s = buf;
    s.resize(count);
    paragraphs[id].push(s);
  }
  string helper = "stop";
  MPI_Send(helper.c_str(), helper.size(), MPI_CHAR, id + 1, 0,
           MPI_COMM_WORLD);

  // bariera
  pthread_barrier_wait(&barrier);
   if(id == 0){
   string outt = input.substr(0, input.size() - 4) + ".out";
    ofstream out(outt);
      for(int o = 0; o < correctOrder.size();o++){
          out << correctOrder[o]<<"\n";   
		      string aux = paragraphs[revconstantMap[correctOrder[o]]].front();
         paragraphs[revconstantMap[correctOrder[o]]].pop();
         out << aux;
      }
   }
     pthread_exit(NULL);
}

void Init(int &provided, int& rank, int &numtasks, int &argc, char* argv[]){
  MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided);
  MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
}

int main(int argc, char* argv[]) {
  int numtasks, rank, id, provided;
  void* status;
  Init(provided, rank, numtasks, argc, argv);
  pthread_t t[1];
  switch(rank){
    case 0: {
        pthread_t threads[THREADS];
        int arguments[THREADS];
        input = argv[1];
        pthread_barrier_init(&barrier, NULL, THREADS);
        int i = 0;
        while(i < THREADS) {
          arguments[i] = i;
          if (pthread_create(&threads[i], NULL, readFunction, &arguments[i])) {
              exit(1);
          }
          i++;
        }
        i = 0;
        while(i < THREADS) {
          if (pthread_join(threads[i], &status)) {
            exit(1);
          }
          i++;
        }
      break;
    }
    case 1: {
        id = 0;
        if (pthread_create(&t[0], NULL, receiver, &id)) {
          exit(1);
        }
        if (pthread_join(t[0], &status)) {
          exit(1);
        }
      break;
    }
    case 2: {
        id = 1;
        if (pthread_create(&t[0], NULL, receiver, &id)) {
          exit(1);
        }
        if (pthread_join(t[0], &status)) {
          exit(1);
        }
      break;
    }
  case 3: {
      id = 2;
      if (pthread_create(&t[0], NULL, receiver, &id)) {
        exit(1);
      }
      if (pthread_join(t[0], &status)) {
        exit(1);
      }
      break;
    }
  case 4: {
      id = 3;
      if (pthread_create(&t[0], NULL, receiver, &id)) {
        exit(1);
      }

      if (pthread_join(t[0], &status)) {
        exit(1);
      }
      break;
    }
  default: {
      break;
    }
  }
  MPI_Finalize();
}